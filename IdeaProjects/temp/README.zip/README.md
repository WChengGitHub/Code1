# Sign In

### 2017.3.29

1.实现申请修改的动态加载 @wang

2.更新了数据库和逆向工程 @wang

### 2017.3.26

1.实现员工的动态加载@wang

2.修复了idea创建项目时存的bug @wang

### 2017.3.25

1.逆向工程 @wang

2.修改了逆序工程存在的错误，增加了一个DepartmentAdminService@wang

### 2017.3.23

1.sql   @zhang

### 2017.3.22

1.HelloWorld   @wang