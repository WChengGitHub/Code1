



function regen() {
	// home
	prepareSlideshow();
	// about
	prepareInternalnav();
	// photos
	preparePlaceholder();
	prepareGallery();
	// live
	stripeTables();
	highlightRows();
	displayAbbreviations();
	// contact
	focusLabels();
	prepareForms();
}


